package com.sam.hotel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sam.hotel.model.Hotel;

public interface HotelRepository extends JpaRepository<Hotel, Long> {
}
