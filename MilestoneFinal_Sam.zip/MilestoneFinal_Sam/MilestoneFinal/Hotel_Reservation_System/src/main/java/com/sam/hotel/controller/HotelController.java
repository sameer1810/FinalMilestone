package com.sam.hotel.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.sam.hotel.model.Hotel;
import com.sam.hotel.service.HotelService;

import java.util.List;

@RestController
@RequestMapping("/api/hotels")
public class HotelController {

    @Autowired
    private HotelService hotelService;

    @GetMapping("/api/hotels/{id}")
    public Hotel getHotelById(@PathVariable Long id) {
        // Example: Return a mock hotel object for demonstration
        Hotel hotel = new Hotel();
        hotel.setId(id);
        hotel.setHotelName("Hotel Blue Moon");
        hotel.setLocation("New York");
        hotel.setRating(4.5);
        return hotel;
    }

    @PostMapping
    public Hotel createHotel(@RequestBody Hotel hotel) {
        return hotelService.createHotel(hotel);
    }
}
